const regname = document.getElementById("name");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const registorlist = document.getElementById("regisList")

document.addEventListener("DOMContentLoaded", loadItems);

function loadItems() {
    const savedItems = JSON.parse(localStorage.getItem("registorList")) || [];

    // ถ้าไม่มี item
    if (savedItems.length === 0) {
        registorlist.innerHTML = `<tr><td colspan="3" style="text-align:center;">Not Found Data !!</td></tr>`;
        return;
    }
    registorlist.innerHTML = `<tr> <th>Name</th> <th>Email</th> <th>Phone Number</th> <th>Action</th> </tr>`;

    savedItems.forEach(item => {
        addRow(item.name, item.email,item.phone,item.id);
    });
}

function register() {
     const nameVal = regname.value.trim();
    const emailVal = email.value.trim();
    const phoneVal = phone.value.trim();

    const isOnlySpecialChars = /^[^a-zA-Zก-๙]+$/.test(nameVal);
    const isOnlyNumbers = /^[0-9]+$/.test(nameVal);
    const isValidPhone = /^0[0-9]{9}$/.test(phoneVal);
    const isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal);

    if (!nameVal || isOnlySpecialChars || isOnlyNumbers || !isValidEmail || !isValidPhone) {
        alert('กรุณากรอกข้อมูลให้ถูกต้อง:\n- ชื่อห้ามเป็นตัวเลขหรือตัวอักษรพิเศษล้วน\n- อีเมลถูกต้อง\n- เบอร์โทรขึ้นต้นด้วย 0 และ 10 หลัก');
        return;
    }

    const itemOb = JSON.parse(localStorage.getItem("registorList")) || [];
    const uniqueId = Date.now(); // หรือใช้ Math.random(), UUID เป็นต้น
    itemOb.push({id: uniqueId, name: regname.value, email: email.value, phone: phone.value});
    localStorage.setItem("registorList", JSON.stringify(itemOb));

    addRow(regname.value, email.value,phone.value,uniqueId)
    regname.value = '';
    email.value = '';
    phone.value = '';
}

function addRow(name, email,phone, id) {
    if (registorlist.rows[0].textContent.includes("Not Found Item")) {
        registorlist.innerHTML = `<tr> <th>Name</th> <th>Email</th> <th>Phone Number</th> <th>Action</th> </tr>`;
    }
    const newRow = document.createElement('tr');
    newRow.dataset.id = id;
    newRow.innerHTML = `
            <td>${name}</td>
            <td>${email}</td>
            <td>${phone}</td>
            <td><button class="delete-btn" onclick="deleteItem(this)">Delete</button></td>`;

    registorlist.appendChild(newRow);
}


function deleteItem(button) {
    const row = button.parentElement.parentElement;
    const id = row.dataset.id;

    let savedItems = JSON.parse(localStorage.getItem("registorList") || []);
    savedItems = savedItems.filter(item => (item.id != id));
    localStorage.setItem("registorList", JSON.stringify(savedItems));

    row.remove();
    if (registorlist.rows.length === 1) {
        registorlist.innerHTML = `<tr><td colspan="3" style="text-align:center;">Not Found Item !!</td></tr>`;
    }
}