const itemName = document.getElementById('item_name');
const itemPrice = document.getElementById('item_price');
const itemlist = document.getElementById("item_list");


// โหลดข้อมูลจาก localStorage ทันทีที่เปิดเว็บ
document.addEventListener("DOMContentLoaded", loadItems);

function loadItems() {
    const savedItems = JSON.parse(localStorage.getItem("myitemlists")) || [];

    // ถ้าไม่มี item
    if (savedItems.length === 0) {
        itemlist.innerHTML = `<tr><td colspan="3" style="text-align:center;">Not Found Item !!</td></tr>`;
        return;
    }
    itemlist.innerHTML = `<tr> <th>Item</th> <th>Price</th> <th>Action</th> </tr>`;

    savedItems.forEach(item => {
        addRow(item.name, item.price);
    });
}


function addItem() {
    const isOnlySpecialChars = /^[^a-zA-Zก-๙]+$/.test(itemName.value.trim());
    const isOnlyNumbers = /^[0-9]+$/.test(itemName.value.trim());

    if (!itemName.value.trim() || isOnlySpecialChars || !itemPrice.value || itemPrice.value < 0 || isOnlyNumbers) {
        alert('Please enter a valid item name (not only special characters) and a price that is 0 or higher.');
        return;
    }

    const itemOb = JSON.parse(localStorage.getItem("myitemlists")) || [];
    itemOb.push({ name: itemName.value, price: itemPrice.value });
    localStorage.setItem("myitemlists", JSON.stringify(itemOb));

    addRow(itemName.value, itemPrice.value)
    itemName.value = '';
    itemPrice.value = '';
}

function addRow(name, price) {
    if (itemlist.rows[0].textContent.includes("Not Found Item")) {
        itemlist.innerHTML = `<tr> <th>Item</th> <th>Price</th> <th>Action</th> </tr>`;
    }
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
            <td>${name}</td>
            <td>$${price}</td>
            <td><button class="delete-btn" onclick="deleteItem(this)">Delete</button></td>`;

    itemlist.appendChild(newRow);
}


function deleteItem(button) {
    const row = button.parentElement.parentElement;
    const name = row.children[0].textContent;
    const price = row.children[1].textContent.replace('$', '');

    let savedItems = JSON.parse(localStorage.getItem("myitemlists") || []);
    savedItems = savedItems.filter(item => !(item.name === name && item.price === price));
    localStorage.setItem("myitemlists", JSON.stringify(savedItems));

    row.remove();
    if (itemlist.rows.length === 1) {
        itemlist.innerHTML = `<tr><td colspan="3" style="text-align:center;">Not Found Item !!</td></tr>`;
    }
}